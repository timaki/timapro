﻿<?php
$dsn = 'mysql:dbname=tt_228_99sv_coco_com;host=localhost';
$user='tt-228.99sv-coco';
$password ='q6CwKMkA';
$pdo = new PDO($dsn,$user,$password);



$id =1;
$nm = "(-.-)";
$kome = "3－7実行しています";//好きな名前、好きな言葉は自分で決めること
$sql = "update tbtest set name='$nm',comment='$kome'where id = $id";
$result = $pdo -> query($sql);


?>
