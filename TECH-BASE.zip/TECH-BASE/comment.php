<?php
$dsn = 'mysql:dbname=tt_228_99sv_coco_com;host=localhost;charset=utf8mb4;';
$user='tt-228.99sv-coco';
$password ='q6CwKMkA';
$pdo = new PDO($dsn,$user,$password);

 require_once("import_media.php");



?>
<ul id= "he">
<li id="username">
<?php
session_start();
print("こんにちは".  $_SESSION["user_name"]."さん");
?>
</li>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
<title>投稿/閲覧ページ</title>
</head>

<body>
  <!-- ヘッダ -->
  <li id="sent"><a href="mission_6-1_t.php">投稿</a></li>
      <li id="logout"><a href="mission_6-1.php">ログアウト</a></li>

</ul>

<div id="header">
  <h1><a href="mission_6-1_main.php">polarimaker</a></h1>
</div>
<!-- メインメニュー -->
	<ul id="menu">
		<li id="menu01"><a href="mission_6-1_main.php">Home</a></li>
		<li id="menu02"><a href="mission_6-1_event.php">event</a></li>
		<li id="menu03"><a href="mission_6-1_mypage.php">MyPage</a></li>

	</ul>
<?php
session_start();
$user_tb= $_SESSION["user_name"];
$id = $_REQUEST["id"];


$sql = " SELECT * FROM  user_tb where id = '$id' ";
$results = $pdo -> query($sql);
foreach($results as $row){

  ?>

  <div id= "to">


    <?php

    echo "No.".$row['id']." ";
    echo "投稿者:";
      if($row['syu']=="pr")
      {
        echo $row['user_name'];

    }else if($row['syu'] == "joins"){
      echo $row['user_work'];
      }

       ?>


      <br/>
  <?php
  echo "<br/>";
  echo "イベント名".$row['event_name']."<br/>";
  echo "開催日"." ".  $row['event_time']."<br/>";
  echo "開催場所".  $row['prefecture']." ";
  echo $row['event_plan ']."<br/>";
  echo $row['tweet']."<br/>";

  //画像か動画か判断して取り出す。

  //動画と画像で場合分け
  $target = $row["fname"];
  if($row["extension"] == "mp4"){
      echo ("<video src=\"import_media.php?target=$target\" width=\"213\" height=\"120\" controls></video>");
  }
  elseif($row["extension"] == "jpeg" || $row["extension"] == "png" || $row["extension"] == "gif"){
      echo ("<img src=\"import_media.php?target=$target\" width=\"10%\" height=\"auto\"></img>");
  }
  echo ("<br/><br/>");
   //線を表示
/*             コメントしたい投稿の表示                                              */
}
   ?>
 </div>
<!--    comment form         -->
 <form  action = "comment.php?id=<?php print($id)?>"  method ="POST"> comment:<br/>
<textarea name ="come" rows="5" cols="40"></textarea><br/>
<input type="submit" name="come_sent" value = "送信"/>
</form>

    <?php
$sql = " SELECT * FROM  user_list where user_id = '$user_tb' ";
$result = $pdo -> query($sql);
foreach($result as $row1){
$user_work = $row1['user_work'];
    }
$yoto = "pr";
$toko = "come_".$id ;
$comment = $_POST["come"];

if(!empty($_POST["come"])){
$sql =$pdo->prepare("INSERT INTO user_tb(toko,syu,tweet,user_name,user_work) VALUES(:toko,:syu,:tweet,:user_name,:user_work);");
$sql -> bindParam(':toko',$toko,PDO::PARAM_STR);
$sql -> bindParam(':syu',$yoto,PDO::PARAM_STR);
$sql -> bindParam(':tweet',$comment,PDO::PARAM_STR);
$sql -> bindParam(':user_name',$user_tb,PDO::PARAM_STR);
$sql -> bindParam(':user_work',$user_work,PDO::PARAM_STR);
$sql -> execute();

}

$sql = "SELECT * FROM  user_tb where toko = '$toko' " ;//tbtest2の内容検索する
$results = $pdo -> query($sql);

foreach($results as $row2){

  echo "No.".$row2['id']." ";
  echo "投稿者:";
      echo $row2['user_name']."<br/>";
      echo $row2['tweet']."<br/>";
     echo "<hr>";
}



?>
