﻿<?php
//文字コードをutf8に変換
mb_convert_encoding($str, 'utf8', 'SJIS-win');
$coment=$_POST["coment"];
$now=date("Y")."年".date("m月d日H時i分");

print("「ご入力ありがとうございます。<br/>{$now}に{$coment}を受け付けました。」");
?>
