<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';//データベースを指定する
$user='tt-228.99sv-coco';//ユーザーを指定する。
$password ='q6CwKMkA';//パスワードを指定する。
$pdo = new PDO($dsn,$user,$password);//データベースに接続する


$sql='SHOW CREATE TABLE tima';//テーブルの中身を確認する
$result = $pdo -> query($sql);//1回だけ使用するSQL文をデータベースへ送信する
foreach($result as $row){
print_r($row); //指定した変数に関する情報を解りやすく出力する
}
echo "<hr>";//線を表示

?>
