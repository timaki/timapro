﻿<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';
$user='tt-228.99sv-coco';
$password='q6CwKMkA';
$pdo = new PDO($dsn,$user,$password);


$sql='SHOW CREATE TABLE tbtest';
$result = $pdo -> query($sql);
foreach($result as $row){
print_r($row); //指定した変数に関する情報を解りやすく出力する
}
echo "<hr>";

?>
