﻿<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--送信場所の設定-->
<form name="input_form" action="mission_2-1.php" method="POST">
<!--テキストボックス-->
<input type="text" name="name"value = "名前"><br/>
<input type="text" name="coment"value = "コメント">
<!--送信ボタン-->
<input type="submit" name="send" value = "送信" ><br/><br/>

<body>
<?php
//文字コードをutf8に変換
mb_convert_encoding($str, 'utf8', 'SJIS-win');

$name=$_POST["name"];//名前を取得
$coment=$_POST["coment"];//コメントを取得
$now=date("Y")."/".date("m/d H:i:s");//時間を取得
$filename = 'mission_2-1_mn.txt';//ファイルを指定


if(isset($_POST['send']))//送信ボタンを得た時動く
{
	if(!empty($_POST["name"])&&($name!="名前"))//名前が空でなく、値が名前以外の時動く
		{
			if(!empty($_POST["coment"])&&($coment!="コメント"))//コメントが空でなく、値がコメント以外の時動く
			{
			

			 
				//テキストファイルに追記モードで書き込む
				$fp=fopen($filename,'a');
				//カウント
			
				$count=(count(file($filename))+1);//投稿番号を行数で取得

				$text = $count."<>".$name."<>".$coment."<>".$now;//取得したデータを一行に連結する
				fwrite($fp,$text."\n");	//書き込む後に改行する
				fclose($fp);//ファイルを閉じる
		}
	}

}else{}

//2－1の内容
$ar = file($filename);
	for ($j = 0; $j < count($ar); $j++)//投稿番号より大きくなったら終了
		{ 
    echo $ar[$j]."<br>";
}

?>

</body>

</html>
