<html>
<meta charset="utf-8">
<form action="mission_2-3.php" method="POST">
 <input type="text" name="name" value="名前"><br>
 <input type="text" name="comment" value="コメント">
 <input type="submit" name="send" value="送信"><br><br>
 <input type="text" name="delete" value="削除番号指定">
 <input type="submit" name="delete-send" value="削除">
</form>
</html>

<?php
header('content-type:text/html;charset=utf-8');
$filename = "mission_2-4_mn.txt";


if(isset($_POST["send"])){
    $name = $_POST[name];
    $comment = $_POST[comment];
    $now = date("Y")."/".date("m/d H:i:s");
  if(!empty($name) && $name != "名前"){
    if(!empty($comment) && $comment != "コメント"){
      $fp = fopen($filename, 'a');
      $count = count(file($filename))+1;
      $text = $count."<>".$name."<>".$comment."<>".$now;
      fwrite($fp, $text."\n" );
      fclose($fp);
    }
  }
}


if(isset($_POST['delete-send'])){
  $delete = $_POST["delete"];
  $delfile = file($filename);
  $fp = fopen($filename,'w');
  @fwrite($fp,"");
  fclose($fp);

  for($j = 0; $j < count($delfile);$j++){
    $deldata = explode("<>",$delfile[$j]);
    if($deldata[0] !=$delete){
      $fp = fopen($filename,'a');
      fwrite($fp,$delfile[$j]);
      fclose($fp);
    }else {}
  }
}

      $contents = file($filename);
      for ($j = 0;$j < count($contents);$j++) {
        echo $contents[$j]."<br>";
      }
?>
