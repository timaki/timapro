﻿<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';//データベースを指定する
$user='tt-228.99sv-coco';//ユーザーを指定する。
$password ='q6CwKMkA';//パスワードを指定する。
$pdo = new PDO($dsn,$user,$password);//データベースに接続する


$sql='DROP TABLE ';
$result = $pdo->query($sql);
$sql='SHOW TABLES';//テーブル一覧を確認するコマンド
$result = $pdo->query($sql);//prepareを使わずにSQL文を実行

foreach($result as $row){//指定した配列に 関してループ処理
echo $row[0];//データベース上に作ったテーブルが表示される。
echo '<br>';
}
echo "<hr>";//線を表示

?>
