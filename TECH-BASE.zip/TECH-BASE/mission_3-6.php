﻿<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';
$user='tt-228.99sv-coco';
$password ='q6CwKMkA';
$pdo = new PDO($dsn,$user,$password);



$sql = 'SELECT * FROM tbtest';
$results = $pdo -> query($sql);
foreach($results as $row){
//$rowの中にはテーブルのカラム名が入る
echo $row['id'].',';
echo $row['name'].',';
echo $row['comment'].'<br>';

}

?>
