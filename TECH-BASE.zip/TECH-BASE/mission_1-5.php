﻿<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--送信指定-->
<form name="input_form" action="mission_1-5.php" method="POST">
<!--テキストボックス-->
<input type="text" name="input"value = "コメント">
<!--送信ボタン-->
<input type="submit" name="send" value = "送信" >
</form>

</html>

<?php
//文字コードをutf8に変換
mb_convert_encoding($str, 'utf8', 'SJIS-win');

//コメントを取得します
$coment=$_POST["input"];
//現在時刻を取得します。
$now=date("Y")."年".date("m月d日H時i分");

//入力フォーム(input)が空でなく、入力値がコメント以外の場合
if(!empty($_POST["input"])&& $coment !="コメント"){

//テキストファイルの作成
$filename = 'mission_1-5_mn.txt';//読み込みたいfile名
$fp=fopen($filename,'w');//上書きモードでファイルを開く
fwrite($fp,$coment);//テキストにコメントを書き込む
fclose($fp);//ファイルを閉じる

if($coment == "完成！"){//分岐：完成！と入力したときのみ動く
	$text = file_get_contents('mission_1-5_mn.txt');//$textにファイルの内容を文字列で全て取得する


	print("「ご入力ありがとうございます。<br/>{$now}に{$text}を受け付けました。」");
	print("<br/>おめでとう");

}else{//分岐：完成！以外を入力したとき


	$text = file_get_contents('mission_1-5_mn.txt');//$textにファイルの内容を文字列で全て取得する
	print("「ご入力ありがとうございます。<br/>{$now}に{$text}を受け付けました。」");

}

}else{}//入力フォーム(input)が空で、入力値がコメントの場合は何も表示しない。



?>

