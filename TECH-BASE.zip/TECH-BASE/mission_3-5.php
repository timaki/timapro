<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';//データベースを指定する
$user='tt-228.99sv-coco';//ユーザーを指定する。
$password ='q6CwKMkA';//パスワードを指定する。
$pdo = new PDO($dsn,$user,$password);//データベースに接続する


//INSERT ステートメントは、テーブルに 1 行以上の新しい行を追加します。
//VALUES 各カラムへのデータ
$sql=$pdo->prepare("INSERT INTO tbtest(id,name,comment) VALUES ('2',:name,:comment)");
  //:name のパラメータに値を入れてます.値は変数です。PDO::PARAM_STR は「文字列だよ」という意味
$sql->bindParam(':name',$name,PDO::PARAM_STR);
  //:comment のパラメータに値を入れてます.値は変数です。PDO::PARAM_STR は「文字列だよ」という意味
$sql->bindParam(':comment',$comment,PDO::PARAM_STR);
//変数nameには以下のデータが入ります。
$name='( ﾟДﾟ)';
//変数commentには以下のデータが入ります。
$comment='どうだ！動いているか？';//好きな言葉は自分で決めること
$sql->execute();//prepare で用意したSQLをここでデータベースにINSERTしてる。これを書かないと実行されない。
?>
