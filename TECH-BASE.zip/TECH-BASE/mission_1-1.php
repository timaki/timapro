<?php
echo "Hello world from(mn)";
?>