﻿<?php
$dsn = 'mysql:dbname=tt_228_99sv_coco_com;host=localhost;charset=utf8mb4;';
$user='tt-228.99sv-coco';
$password ='q6CwKMkA';
$pdo = new PDO($dsn,$user,$password);

$id=1;
$sql = "delete from tbtest where id = $id";
$result = $pdo->query($sql);



?>

