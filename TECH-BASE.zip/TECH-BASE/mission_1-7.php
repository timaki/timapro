﻿<?php
//文字コードをutf8に変換
mb_convert_encoding($str, 'utf8', 'SJIS-win');

$text = file_get_contents('mission_1-6_mn.txt');
$array = explode(PHP_EOL, trim($text));

foreach($array as $array){ //arrayの先頭から１つずつ$arrayに代入する
    echo $array;
    echo "<br>";
}
?>
