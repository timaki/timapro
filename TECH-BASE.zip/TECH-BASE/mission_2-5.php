﻿<!DOCTIPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>mission_2-4</title>
</head>

<body>
<!--フォームを作成-->
<form  action="mission_2-5.php" method="POST">

<!--名前のフォーム-->
<input type="text" name="name"value = "名前"><br/>

<!--コメントのフォーム-->
<input type="text" name="coment"value = "コメント"><br/>

<!--パスワードのフォーム-->
<input type="text" name="pass"value = "パスワード">

<!--送信ボタン-->
<input type="submit" name="send" value = "送信" ><br/><br/>

<!--削除のフォーム-->
<input type="text" name="deleteNO"value="削除対象番号"><br/>

<!--パスワードのフォーム-->
<input type="text" name="d_pass"value = "パスワード">
<!--削除ボタン-->
<input type="submit" name="delete" value="削除"><br/><br/>

<!--編集対象番号のフォーム-->
<input type="text" name="hensyu"value = "編集対象番号"><br/>

<!--パスワードのフォーム-->
<input type="text" name="h_pass"value = "パスワード">
<input type="submit" name="hensyu_botton" value="編集">
 </form>

<?php
//phpのプログラム


		
$filename = 'mission_2-5_mn.txt';
$passfile = 'passward.txt';

	$name=$_POST["name"];
	$coment=$_POST["coment"];
	$now=date("Y")."/".date("m/d H:i:s");
	$pass=$_POST["pass"];




//入力フォーム
if(isset($_POST['send']))
{
	if(!empty($_POST["pass"])&&($pass!="パスワード"))
	{
		
		$fp_pass =fopen($passfile,'w');//パスワードを上書きで書き込む
		fwrite($fp_pass,$pass."<>");
		fclose($fp_pass);
		
		if(!empty($_POST["name"])&&($name!="名前"))
		{
			if(!empty($_POST["coment"])&&($coment!="コメント"))
			{
			$line=file($filename);

			 
				//テキストファイルに書き込む
				$fp=fopen($filename,'a');
				//カウント
			
				$count=(count(file($filename))+1);//

				$text = $count."<>".$name."<>".$coment."<>".$now;
				fwrite($fp,$text."\n");
				fclose($fp);
			}
		}

	}else{print("パスワードが記入されてません<br/>");}
}

		//passward.txtを配列に格納。
		
		$passward= file($passfile);
		$passData = explode("<>", $passward[0]);



$hensyu=$_POST["hensyu"];
$h_pass=$_POST["h_pass"];
if(isset($_POST['hensyu_botton']))
{
//編集モード
	if(!empty($_POST["h_pass"])&&($h_pass!="パスワード"))
	{
		if($h_pass == $passData[0])
		{
		if(!empty($_POST["hensyu"])&&($hensyu!="編集対象番号"))
		{
			if(!empty($_POST["name"])&&($name!="名前"))
			{
				if(!empty($_POST["coment"])&&($coment!="コメント"))
				{

					$hefile= file($filename);
					$fp=fopen($filename,'w');//テキストファイルの上書き保存。初期化する
					@fwrite($fp,"");
					fclose($fp);

					for ($i = 0; $i < count($hefile); $i++)//投稿番号より大きくなったら終了する
					{
						$heData = explode("<>", $hefile[$i]); //配列[i]を<>で分割する
						if ($heData[0] == $hensyu)  //配列[0] == 編集番号と一緒だったら
						{ 
							$heData[1]=$name;
							$heData[2]=$coment;
							$text=$heData[0]."<>".$heData[1]."<>".$heData[2]."<>".$heData[3];
					
							$fp=fopen($filename,'a');
							fwrite($fp,$text);
							fclose($fp);
				
						}else{	
							$fp=fopen($filename,'a');
							fwrite($fp,$hefile[$i]);
							fclose($fp);
						}
		
					}
				}
			}
		}
		}else{print("パスワードが違います<br/>");}
	}else{print("パスワードが記入されてません<br/>");}
}



$d_pass=$_POST["d_pass"];
if (isset($_POST['delete']))
{ //もし削除ボタンを受けたら
	if(!empty($_POST["d_pass"])&&($d_pass!="パスワード"))
	{
		if($d_pass == $passData[0])
		{
		$delete = $_POST["deleteNO"];    //削除対象番号を受け取る
		$defile = file($filename); //先にファイルを配列に格納
		$fp=fopen($filename,'w');//テキストファイルの上書き保存。初期化する
		@fwrite($fp,"");
		fclose($fp);

		for ($j = 0; $j < count($defile); $j++)//投稿番号より大きくなったら
		{ 
			$delData = explode("<>", $defile[$j]); //配列[j]を<>で分割する

			if ($delData[0] != $delete)  //配列[0] == 削除番号と一緒じゃなかったら
			{ 
				$fp=fopen($filename,'a');
				fwrite($fp,$defile[$j]);
				fclose($fp);
			}else{
			
				}//一緒だったら何もしない
		}
		}else{print("パスワードが違います<br/>");}

	}else{print("パスワードが記入されてません<br/>");}
}




//テキストの中身を表示　2-1の内容

$ar = file($filename);
	for ($j = 0; $j < count($ar); $j++)//投稿番号より大きくなったら終了
		{ 
    echo $ar[$j]."<br>";
}


?>

</body>
</html>
