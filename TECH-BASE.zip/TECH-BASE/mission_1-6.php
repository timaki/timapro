﻿<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--送信指定-->
<form name="input_form" action="mission_1-6.php" method="POST">
<!--テキストボックス-->
<input type="text" name="coment"value = "コメント">
<!--送信ボタン-->
<input type="submit" name="send" value = "送信" >
</form>

</html>

<?php
//文字コードをutf8に変換
mb_convert_encoding($str, 'utf8', 'SJIS-win');
//コメントを取得します
$coment=$_POST["coment"];

//入力フォーム(input)が空でなく、入力値がコメント以外の場合
if(!empty($_POST["coment"])&&coment!="コメント"){

//テキストファイルの作成1－6の内容
 	$filename = 'mission_1-6_mn.txt';//読み込みたいfile名
	 $fp=fopen($filename,"a");//追記モードでファイルを開く
	 fwrite($fp,$coment."\n");//テキストにコメントを書き込む.そのあと改行する
	 fclose($fp);//ファイルを閉じる


//ファイルを配列に読み込む、１－７の内容
	$arra = file('mission_1-6_mn.txt');


//1～3行目まで表示する。


    		echo $arra[0]."<br>";
    		echo $arra[1]."<br>";
		echo $arra[2]."<br>";
	
}else{}



?>

