﻿<?php

//PDOクラスのオブジェクトの作成
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';
$user='tt-228.99sv-coco';
$password ='q6CwKMkA';
$pdo=new PDO($dsn,$user, $password);




?>
