﻿<?php

mb_convert_encoding($str, 'utf8', 'SJIS-win');
//ブラウザに表示mission2-2の内容
$str = file_get_contents('mission_2-1_mn.txt');
$arr = explode(PHP_EOL, trim($str));

foreach($arr as $arr){ //arrayの先頭から１つずつ$arrayに代入する
    echo $arr;
    echo "<br>";
}


?>
