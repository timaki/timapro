<?php
$dsn ='mysql:dbname=tt_228_99sv_coco_com;host=localhost';//データベースを指定する
$user='tt-228.99sv-coco';//ユーザーを指定する。
$password ='q6CwKMkA';//パスワードを指定する。
$pdo = new PDO($dsn,$user,$password);//データベースに接続する




$a="testtb"

//tbtestというテーブルを作成する。テーブルのカラムはid,name,comment
$sql ="CREATE TABLE $a"."("."id INT,"."name char(32),"."comment TEXT".");";
$stmt = $pdo->query($sql);//1回だけ使用するSQL文をデータベースへ送信する
?>
