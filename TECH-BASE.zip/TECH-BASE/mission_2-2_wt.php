<html>
<meta charset="utf-8">
<form action="mission_2-2_wt.php" method="POST">
 <input type="text" name="name" value="名前"><br>
 <input type="text" name="comment" value="コメント"><br>
 <input type="submit" name="send" value="送信">
</form>
</html>

<?php
header('content-type:text/html;charset=utf-8');

$name = $_POST[name];
$comment = $_POST[comment];
$now=date("Y")."/".date("m/d H:i:s");
$filename = "mission_2-1_wt.txt";

if(isset($_POST["send"])){
  if(!empty($name) && $name != "名前"){
    if(!empty($comment) && $comment != "コメント"){
      $fp = fopen($filename, 'a');
      $count = count(file($filename))+1;
      $text = $count."<>".$name."<>".$comment."<>".$now;
      fwrite($fp, $text."\n" );
      fclose($fp);
      $contents = file($filename);

        echo $contents[1]."<br>";
      
    }
  }
}

?>
