<?php

$dsn = 'mysql:;host=localhost;charset=utf8mb4;';
$user='';
$password ='';
$pdo = new PDO($dsn,$user,$password);


session_start();
$user_tb=$_SESSION["user_name"];
?>

<ul id= "he">
<li id="username">
<?php
session_start();
print("こんにちは".  $_SESSION["user_name"]."さん");
?>
</li>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
<title>投稿/閲覧ページ</title>
</head>

<body>
  <!-- ヘッダ -->
  <li id="sent"><a href="mission_6-1_t.php">投稿</a></li>
      <li id="logout"><a href="mission_6-1.php">ログアウト</a></li>

</ul>

<div id="header">
  <h1><a href="mission_6-1_main.php">polarimaker</a></h1>
</div>

<!-- メインメニュー -->
	<ul id="menu">
		<li id="menu01"><a href="mission_6-1_main.php">Home</a></li>
		<li id="menu02"><a href="mission_6-1_event.php">event</a></li>
		<li id="menu03"><a href="mission_6-1_mypage.php">MyPage</a></li>

	</ul>

  <form  action="mission_6-1_mypage.php" method="POST">
    削除したい投稿番号を記入してください<br>
  <input type="text" name="deleteNO"value="">
  <input type="submit" name ="delet_b" value ="削除">
</form>


<hr>
<?php

$sql = "SELECT * FROM  user_tb where user_name = '$user_tb' ";//tbtest2の内容検索する
$result = $pdo -> query($sql);
foreach($result as $row){

  $user_name =  $row['user_name'];


$id_d = $_POST["deleteNO"];
//削除フォーム

if (!empty($_POST["delet_b"])){ //もし削除ボタンを受けたら
if(!empty($_POST["deleteNO"])){
  if($row['id'] == $id_d && $user_name == $user_tb){


  $sql = "DELETE  FROM user_tb where id = '$id_d' ";
  $result = $pdo->query($sql);
}else{print("この番号は削除できません");}
}else{print("削除投稿番号が記入されていません");}

}


?>
<div id= "to">


  <?php
if($row['toko'] == "tweet" || $row['toko'] == "event_tweet")
{
  echo "No.".$row['id']." ";
  echo "投稿者:";
    if($row['syu']=="pr")
    {
      echo $row['user_name'];

    }else if($row['syu'] == "joins"){
    echo $row['user_work'];
    }

     ?>


    <br/>
<?php
echo "<br/>";
echo "イベント名".$row['event_name']."<br/>";
echo "開催日"." ".  $row['event_time']."<br/>";
echo "開催場所".  $row['prefecture']." ";
echo $row['event_plan ']."<br/>";
echo $row['tweet']."<br/>";

//画像か動画か判断して取り出す。

//動画と画像で場合分け
$target = $row["fname"];
if($row["extension"] == "mp4"){
    echo ("<video src=\"import_media.php?target=$target\" width=\"213\" height=\"120\" controls></video>");
}
elseif($row["extension"] == "jpeg" || $row["extension"] == "png" || $row["extension"] == "gif"){
    echo ("<img src=\"import_media.php?target=$target\" width=\"10%\" height=\"auto\"></img>");


}
?>
  <td class ="comment"><a href = "comment.php?id=<?php pr($row["id"]); ?>">コメント</a></td>
<?php
echo ("<br/><br/>");
 echo "<hr>";//線を表示
}else{
  echo "No.".$row['id']." ";
  echo "投稿者:";
      echo $row['user_name']."<br/>";
      echo $row['tweet']."<br/>";
     echo "<hr>";
  }
}




 ?>

</div>
</html>
