<html>

<head>
<link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
    <meta charset="utf-8">
<title>新規追加ページ</title>
</head>
<body>



<?php

$dsn = 'mysql:;host=localhost;charset=utf8mb4;';
$user='';
$password ='';
$pdo = new PDO($dsn,$user,$password);

/*
$sql ="CREATE TABLE user_list"
."("."id INT AUTO_INCREMENT,"//連番でidを記述する
."user_name char(32),"//名前
."user_work char(32),"//名前
."gender char(32),"//
."user_id char(32),"//
."user_password char(32),"//
."INDEX(id)".");";//これがないと完成しない
$stmt = $pdo->query($sql);
*/
$error_message = "";

// ログインボタンが押されたかを判定
// 初めてのアクセスでは認証は行わずエラーメッセージは表示しないように
if (isset($_POST["sing"])) {


if (!empty($_POST["user_name"])&&!empty($_POST["user_work"])&&!empty($_POST["user_id"])&&!empty($_POST["user_password"])) {

  $user_name=$_POST["user_name"];  //フォームの値を受け取り格納する　名前
	$user_work=$_POST["user_work"];//所属名
	$gender=$_POST["gender"];//id
	$user_id=$_POST["user_id"];//id
	$user_password=$_POST["user_password"];//パスワード


  //投稿内容を受け取る場所
  $sql=$pdo->prepare("INSERT INTO user_list(user_name,user_work,gender,user_id,user_password) VALUES (:user_name,:user_work,:gender,:user_id,:user_password)");
  $sql->bindParam(':user_name',$user_name,PDO::PARAM_STR);
  $sql->bindParam(':user_work',$user_work,PDO::PARAM_STR);

  $sql->bindParam(':gender',$gender,PDO::PARAM_STR);
  $sql->bindParam(':user_id',$user_id,PDO::PARAM_STR);

  $sql->bindParam(':user_password',$user_password,PDO::PARAM_STR);
  $sql->execute();

}
else{$error_message = "記入されていない項目があります。";}
}


?>



<h1 id="new">新規登録画面</h1>
  <captiion>以下の項目に入力してください</caption>

<?php
if ($error_message) {
print '<font color="red">'.$error_message.'</font>';
}
?>
<div id =new>
<form action="mission_6-1_new.php" method="POST">
<table tyle="table-layout: auto;">


<tr>
<th>氏名（必須）</th>
<td><input type="text" name="user_name" value="" /></td>
</tr>

<tr>
<th>所属名（必須）</th>
<td><input type="text" name="user_work" value="" /></td>
</tr>


<tr>
<th>性別</th>
<td>
<input type="radio" name="gender" value="男性">男性&nbsp;
<input type="radio" name="gender" value="女性">女性
</td>
</tr>

<tr>
<th>ID（必須）</th>
<td><input type="text" name="user_id" value="" /></td><br />
</tr>

<tr>
<th>パスワード（必須）</th>
<td>  <input type="password" name="user_password" value"" /></td><br />
</tr>

</table>
<input type="submit" name="sing" value="登録" class="Btn-gray button"/>
  </form>

<form action="mission_6-1.php" method="POST">
<input type="submit" name="back" value="戻る" />
</form>
<div>

<?php
$t="user_list";


  //テキストの中身を表示'
  $sql = 'SELECT * FROM '.$t;//tbtest2の内容検索する
  $results = $pdo -> query($sql);
  foreach($results as $row){
  //$rowの中にはテーブルのカラム名が入る

  echo $row['user_id'].',';
  echo $row['user_password'].'<br>';
  }



 ?>










</body>
</html>
