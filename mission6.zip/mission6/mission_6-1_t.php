<?php
try{
  $dsn = 'mysql:;host=localhost;charset=utf8mb4;';
  $user='';
  $password ='';
  $pdo = new PDO($dsn,$user,$password);

/*
$sql = "CREATE TABLE user_tb
(id INT AUTO_INCREMENT,
toko char(32),
syu char(32),
event_name VARCHAR(32),
event_time TIMESTAMP,
prefecture char(32),
event_plan VARCHAR(32),
tweet TEXT,
fname TEXT ,
extension TEXT,
raw_data LONGBLOB,
user_name char(32),
user_work char(32),
INDEX(id));";//これがないと完成しない
$stmt = $pdo->query($sql);//1回だけ使用するSQL文をデータベースへ送信する
*/
session_start();

$user_tb=$_SESSION["user_name"];

$sql = " SELECT * FROM  user_list where user_id = '$user_tb' ";
$result = $pdo -> query($sql);
foreach($result as $row1){
  $user_work = $row1['user_work'];
}

 //ファイルアップロードがあったとき
         if (isset($_FILES['upfile']['error']) && is_int($_FILES['upfile']['error']) && $_FILES["upfile"]["name"] !== ""){
             //エラーチェック
             switch ($_FILES['upfile']['error']) {
                 case UPLOAD_ERR_OK: // OK
                     break;
                 case UPLOAD_ERR_NO_FILE:   // 未選択
                     throw new RuntimeException('ファイルが選択されていません', 400);
                 case UPLOAD_ERR_INI_SIZE:  // php.ini定義の最大サイズ超過
                     throw new RuntimeException('ファイルサイズが大きすぎます', 400);
                 default:
                     throw new RuntimeException('その他のエラーが発生しました', 500);
             }

             //画像・動画をバイナリデータにする．
                        $raw_data = file_get_contents($_FILES['upfile']['tmp_name']);

                        //拡張子を見る
                        $tmp = pathinfo($_FILES["upfile"]["name"]);
                        $extension = $tmp["extension"];
                        if($extension === "jpg" || $extension === "jpeg" || $extension === "JPG" || $extension === "JPEG"){
                            $extension = "jpeg";
                        }
                        elseif($extension === "png" || $extension === "PNG"){
                            $extension = "png";
                        }
                        elseif($extension === "gif" || $extension === "GIF"){
                            $extension = "gif";
                        }
                        elseif($extension === "mp4" || $extension === "MP4"){
                            $extension = "mp4";
                        }
                        else{
                            echo "非対応ファイルです．<br/>";
                            echo ("<a href=\"index.php\">戻る</a><br/>");
                            exit(1);
                        }

                        //DBに格納するファイルネーム設定
                                  //サーバー側の一時的なファイルネームと取得時刻を結合した文字列にsha256をかける．
                                  $date = getdate();
                                  $fname = $_FILES["upfile"]["tmp_name"].$date["year"].$date["mon"].$date["mday"].$date["hours"].$date["minutes"].$date["seconds"];
                                  $fname = hash("sha256", $fname);
  	// ファイル取得

$toko = $_POST["toko"];
$syu = $_POST["yoto"];
$event_name = $_POST["event_name"];
$event_time = $_POST["Y"]."-".$_POST["M"]."-".$_POST["d"]."-".$_POST["h"]."-".$_POST["s"];
$prefecture = $_POST["prefecture"];
$event_plan = $_POST["event_plan"];
$tweet = $_POST["tweet"];




//画像・動画をDBに格納．
$sql=$pdo->prepare("INSERT INTO user_tb(toko, syu, event_name, event_time, prefecture, event_plan, tweet, fname, extension, raw_data,user_name,user_work) VALUES(:toko,:syu,:event_name,:event_time,:prefecture, :event_plan,:tweet,:fname, :extension, :raw_data, :user_name,:user_work);");


$sql -> bindParam(':toko',$toko,PDO::PARAM_STR);
$sql -> bindParam(':syu',$syu,PDO::PARAM_STR);
$sql -> bindParam(':event_name',$event_name,PDO::PARAM_STR);
$sql -> bindParam(':event_time',$event_time,PDO::PARAM_STR);
$sql -> bindParam(':prefecture',$prefecture,PDO::PARAM_STR);
$sql -> bindParam(':event_plan',$event_plan,PDO::PARAM_STR);
$sql -> bindParam(':tweet',$tweet,PDO::PARAM_STR);
$sql -> bindParam(":fname",$fname, PDO::PARAM_STR);
$sql -> bindParam(":extension",$extension, PDO::PARAM_STR);
$sql -> bindParam(":raw_data",$raw_data, PDO::PARAM_STR);
$sql -> bindParam(':user_name',$user_tb,PDO::PARAM_STR);
$sql -> bindParam(':user_work',$user_work,PDO::PARAM_STR);
$sql -> execute();
}

}
catch(PDOException $e){
echo("<p>500 Inertnal Server Error</p>");
exit($e->getMessage());
}
?>
<ul id= "he">
<li id="username">
<?php
session_start();
print("こんにちは".  $_SESSION["user_name"]."さん");
?>
</li>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
<title>投稿/閲覧ページ</title>
</head>

<body>
  <!-- ヘッダ -->
  <li id="sent"><a href="mission_6-1_t.php">投稿</a></li>
      <li id="logout"><a href="mission_6-1.php">ログアウト</a></li>

</ul>


<div id="header">
  <h1><a href="mission_6-1_main.php">polarimaker</a></h1>
</div>

	<ul id="menu">
		<li id="menu01"><a href="mission_6-1_main.php">Home</a></li>
		<li id="menu02"><a href="mission_6-1_event.php">event</a></li>
		<li id="menu03"><a href="mission_6-1_mypage.php">MyPage</a></li>

	</ul>


<form action="mission_6-1_t.php" enctype="multipart/form-data" method="POST">
  <tr>
  <th>投稿項目</th>
  <td>
  <input type="radio" name="toko" value="tweet">つぶやき&nbsp;
  <input type="radio" name="toko" value="event_tweet">イベント
  </td>
  </tr>



<div id = "t">
  <table>
    <tr>
    <th>主催</th>
    <td>
    <input type="radio" name="yoto" value="pr">個人&nbsp;
    <input type="radio" name="yoto" value="joins">所属
    </td>
    </tr>
    <tr>
    <th>イベント名</th><td><input type="text" name="event_name"/></td>
    </tr>
    <tr>
    <th>開催日</th>
    <td>
      日付<input type="text" size ="4" name="Y"/> /
      <input type="text"size ="4" name="M"/> /
      <input type="text"size ="4" name="d"/><br/>
      時刻<input type="text"size ="4" name="h"/> :
<input type="text"size ="4" name="s"/>

    </td>
    </tr>

    <tr>
    <th>開催都道府県</th>
    <td><select name = "prefecture">
  <option value="北海道">北海道</option> <option value="青森">青森</option>
  <option value="岩手">岩手</option> <option value="宮城">宮城</option> <option value="秋田">秋田</option>
  <option value="山形">山形</option> <option value="福島">福島</option>
  <option value="茨城">茨城</option>   <option value="栃木">栃木</option>   <option value="群馬">群馬</option>
  <option value="埼玉">埼玉</option>  <option value="千葉">千葉</option>   <option value="東京">東京</option>
  <option value="神奈川">神奈川</option>  <option value="新潟">新潟</option>   <option value="富山">富山</option>
  <option value="石川">石川</option>   <option value="福井">福井</option>   <option value="山梨">山梨</option>
  <option value="長野">長野</option>  <option value="岐阜">岐阜</option>   <option value="静岡">静岡</option>
  <option value="愛知">愛知</option>  <option value="三重">三重</option>   <option value="滋賀">滋賀</option>
  <option value="京都">京都</option> <option value="大阪">大阪</option>   <option value="兵庫">兵庫</option>
  <option value="奈良">奈良</option> <option value="和歌山">和歌山</option>   <option value="鳥取">鳥取</option>
  <option value="島根">島根</option> <option value="岡山">岡山</option>   <option value="広島">広島</option>
  <option value="山口">山口</option> <option value="徳島">徳島</option>   <option value="香川">香川</option>
  <option value="愛媛">愛媛</option> <option value="高知">高知</option>   <option value="福岡">福岡</option>
  <option value="佐賀">佐賀</option> <option value="長崎">長崎</option>   <option value="熊本">熊本</option>
  <option value="大分">大分</option> <option value="宮崎">宮崎</option>   <option value="鹿児島">鹿児島</option>
   <option value="沖縄">沖縄</option>
  </td>
  </tr>



    <tr>
    <th>イベント会場</th><td><input type="text" name="event_plan"/></td>
    </tr>



  <tr>
  <th>イベント内容</th><td><textarea name="tweet" rows="4" cols="35"></textarea></td>
  </tr>


<tr>
    <th>画像/動画アップロード</th>
<td>  <input type="file" name="upfile"><br>
  ※画像はjpeg方式，png方式，gif方式に対応しています．動画はmp4方式のみ対応しています．<br></td>
  <br>

  </tr>



</table>
</div>


<input type="submit" name="send" value = "送信" /><br/><br/>


<input type="reset" name="reset" value="リセット"/>
</form>
</body>
</html>
