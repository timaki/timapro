<html>
<head>
       <link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
    <meta charset="utf-8">
<title>ログイン画面</title>
</head>
<body>

<?php
$dsn = 'mysql:;host=localhost;charset=utf8mb4;';
$user='';
$password ='';
$pdo = new PDO($dsn,$user,$password);



session_start();

// エラーメッセージを格納する変数を初期化
$error_message = "";

// ログインボタンが押されたかを判定
// 初めてのアクセスでは認証は行わずエラーメッセージは表示しないように

if (isset($_POST["login"])) {
    // 1. ユーザIDの入力チェック
        if (empty($_POST["user_name"])) {
   // emptyは値があるときの動作
                $errorMessage = 'ユーザーIDが未入力です。';

          } else if (empty($_POST["password"])) {
  // emptyは値がないときの動作
                $errorMessage = 'パスワードが未入力です。';
              }

              if (!empty($_POST["user_name"]) && !empty($_POST["password"])) {
//username&passwordが入力されたときの動作
                  $sql = 'SELECT * FROM  user_list';
                  $results = $pdo -> query($sql);

                  foreach($results as $row){
    //$rowの中にはテーブルのカラム名が入る
                      $test= $row['user_id'];//テストにパスワードを格納
                      $test2= $row['user_password'];//テストにパスワードを格納
                      if ($_POST["user_name"] == $test && $_POST["password"] == $test2) {

    // ログインが成功した証をセッションに保存
                              $_SESSION["user_name"] = $_POST["user_name"];

    // 管理者専用画面へリダイレクト
                              $login_url = "http://{$_SERVER["HTTP_HOST"]}/mission_6-1_main.php";
                              header("Location: {$login_url}");
                              exit;
                            }

                          }
// user_nameが「php」でpasswordが「password」だとログイン出来るようになっている
                        $error_message = "ユーザ名もしくはパスワードが違っています。";
                      }
                    }



                    if ($error_message) {
                        print '<font color="red">'.$error_message.'</font>';
                      }
?>

<div id = "login">
<img class="sample1" src = polaris.png >

<form action="mission_6-1.php" method="POST">
ユーザID：<input type="text" name="user_name" value="" /><br />
パスワード：<input type="password" name="password" value"" /><br />
<input type="submit" name="login" value="ログイン" />
</form>

<form action="mission_6-1_new.php" method="POST">
<input type="submit" name="new_user" value="新規登録" />
</form>
</div>

<?php



  echo $user_name.$user_work.	$gender.$user_id.	$user_password."<br>";


 ?>

</body>
</html>
