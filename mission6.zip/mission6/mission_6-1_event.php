<?php

$dsn = 'mysql:;host=localhost;charset=utf8mb4;';
$user='';
$password ='';
$pdo = new PDO($dsn,$user,$password);


session_start();

$user_tb= $_SESSION["user_name"];

function tw_pr($user_tb,$pdo,$pr ){



  //$rowの中にはテーブルのカラム名が入る

$sql = "SELECT * FROM  user_tb where prefecture = '$pr' and toko = 'event_tweet'";
  $results = $pdo -> query($sql);
  foreach($results as $row){

    ?>
    <div id= "to">


      <?php
$id_comme = $row['id'];
      echo "No.".$row['id']." ";
      echo "投稿者:";
        if($row['syu']=="pr")
        {
          echo $row['user_name'];

      }else if($row['syu'] == "joins"){
        echo $row['user_work'];
        }

         ?>


        <br/>
    <?php
    echo "<br/>";
    echo "イベント名".$row['event_name']."<br/>";
    echo "開催日"." ".  $row['event_time']."<br/>";
    echo "開催場所".  $row['prefecture']." ";
    echo $row['event_plan ']."<br/>";
    echo $row['tweet']."<br/>";

    //画像か動画か判断して取り出す。

    //動画と画像で場合分け
    $target = $row["fname"];
    if($row["extension"] == "mp4"){
        echo ("<video src=\"import_media.php?target=$target\" width=\"213\" height=\"120\" controls></video>");
    }
    elseif($row["extension"] == "jpeg" || $row["extension"] == "png" || $row["extension"] == "gif"){
        echo ("<img src=\"import_media.php?target=$target\" width=\"10%\" height=\"auto\"></img>");
    }
    ?>
    <td class ="comment"><a href = comment.php?id=<?php print($id_comme); ?>>コメント</a></td>
<?php
    echo ("<br/><br/>");
     echo "<hr>";//線を表示
     ?>
   </div>
   <?php
    }

}

?>


<ul id= "he">
<li id="username">
<?php
session_start();
print("こんにちは".  $_SESSION["user_name"]."さん");
?>
</li>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="mission_6-1_main.css">
<title>投稿/閲覧ページ</title>
</head>

<body>
  <!-- ヘッダ -->
  <li id="sent"><a href="mission_6-1_t.php">投稿</a></li>
      <li id="logout"><a href="mission_6-1.php">ログアウト</a></li>

</ul>

<div id="header">
  <h1><a href="mission_6-1_main.php">polarimaker</a></h1>
</div>
 <!-- メインメニュー -->
 	<ul id="menu">
 		<li id="menu01"><a href="mission_6-1_main.php">Home</a></li>
 		<li id="menu02"><a href="mission_6-1_event.php">event</a></li>
		<li id="menu03"><a href="mission_6-1_mypage.php">MyPage</a></li>

 	</ul>
  <form action="mission_6-1_event.php" method="POST">

  <ul id ="pre">
<li class = "hokkai">

<input id="hokkai" type="submit" name="prefecture_botan" value="北海道" /><br/>

</a></li>
<li class = "tohoku">
<a><input id="tohoku" type="submit" name="prefecture_botan" value="青森" />
<input id="tohoku" type="submit" name="prefecture_botan" value="岩手" />
<input id="tohoku" type="submit" name="prefecture_botan" value="宮城" />
<input id="tohoku" type="submit" name="prefecture_botan" value="秋田" />
<input id="tohoku" type="submit" name="prefecture_botan" value="山形" />
<input id="tohoku" type="submit" name="prefecture_botan" value="福島" /><br/>
</a></li>

<li class="kanto"><a>
<input id="kanto" type="submit" name="prefecture_botan" value="茨城" />
<input id="kanto" type="submit" name="prefecture_botan" value="栃木" />
<input id="kanto" type="submit" name="prefecture_botan" value="群馬" />
<input id="kanto" type="submit" name="prefecture_botan" value="埼玉" />
<input id="kanto" type="submit" name="prefecture_botan" value="千葉" />
<input id="kanto" type="submit" name="prefecture_botan" value="東京" />
<input id="kanto" type="submit" name="prefecture_botan" value="神奈川" /><br/>
</a></li>

<li class = "tyubu"><a>

<input id="tyubu" type="submit" name="prefecture_botan" value="新潟" />
<input id="tyubu" type="submit" name="prefecture_botan" value="富山" />
<input id="tyubu" type="submit" name="prefecture_botan" value="石川" />
<input id="tyubu" type="submit" name="prefecture_botan" value="福井" />
<input id="tyubu" type="submit" name="prefecture_botan" value="山梨" />

<input id="tyubu" type="submit" name="prefecture_botan" value="長野" />
<input id="tyubu" type="submit" name="prefecture_botan" value="岐阜" />
<input id="tyubu" type="submit" name="prefecture_botan" value="静岡" />
<input id="tyubu" type="submit" name="prefecture_botan" value="愛知" /><br/>
</a></li>

<li class = "kinki"><a>
<input id="kinki" type="submit" name="prefecture_botan" value="三重" />
<input id="kinki" type="submit" name="prefecture_botan" value="滋賀" />
<input id="kinki" type="submit" name="prefecture_botan" value="京都" />
<input id="kinki" type="submit" name="prefecture_botan" value="大阪" />
<input id="kinki" type="submit" name="prefecture_botan" value="兵庫" />
<input id="kinki" type="submit" name="prefecture_botan" value="奈良" />
<input id="kinki" type="submit" name="prefecture_botan" value="和歌山" /><br/>

</a></li>
<li class = "tyugoku"><a>
<input id="tyugoku" type="submit" name="prefecture_botan" value="鳥取" />
<input id="tyugoku" type="submit" name="prefecture_botan" value="島根" />
<input id="tyugoku" type="submit" name="prefecture_botan" value="岡山" />
<input id="tyugoku" type="submit" name="prefecture_botan" value="広島" />
<input id="tyugoku" type="submit" name="prefecture_botan" value="山口" /><br/>

</a></li>
<li class = "sikoku"><a>
<input id="sikoku" type="submit" name="prefecture_botan" value="徳島" />
<input id="sikoku" type="submit" name="prefecture_botan" value="香川" />
<input id="sikoku" type="submit" name="prefecture_botan" value="愛媛" />
<input id="sikoku" type="submit" name="prefecture_botan" value="高知" /><br/>

</a></li>
<li class = "kyusyu"><a>
<input id="kyusyu" type="submit" name="prefecture_botan" value="福岡" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="佐賀" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="長崎" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="熊本" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="大分" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="宮崎" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="鹿児島" />
<input id="kyusyu" type="submit" name="prefecture_botan" value="沖縄" />

</a></li>
</ul>
  </form>
<hr>
  <?php

  $prefecture=$_POST['prefecture_botan'];




  if($prefecture == "北海道")
  {

 tw_pr($user_tb,$pdo,'北海道');
  }
  else if($prefecture == '青森')
  {
 tw_pr($user_tb,$pdo,'青森');
  }
  else if($prefecture == "岩手")
  {
    tw_pr($user_tb,$pdo,'岩手');

  }
  else if($prefecture == "宮城")
  {

     tw_pr($user_tb,$pdo,"宮城");
  }
  else if($prefecture == "秋田")
  {
 tw_pr($user_tb,$pdo,$prefecture);
  }
  else if($prefecture == "山形")
  {
    tw_pr($user_tb,$pdo,$prefecture);
  }
    else if($prefecture == "福島")
    {
      tw_pr($user_tb,$pdo,$prefecture);
    }
      else if($prefecture == "茨城")
      {
        tw_pr($user_tb,$pdo,$prefecture);
      }
        else if($prefecture == "栃木")
        {
          tw_pr($user_tb,$pdo,$prefecture);
        }
          else if($prefecture == "群馬")
          {tw_pr($user_tb,$pdo,$prefecture);
          }
            else if($prefecture == "埼玉")
            {
              tw_pr($user_tb,$pdo,$prefecture);
            }
              else if($prefecture == "千葉")
              {
                tw_pr($user_tb,$pdo,$prefecture);
              }
                else if($prefecture == "東京")
                {
                  tw_pr($user_tb,$pdo,$prefecture);
                }
                  else if($prefecture == "神奈川")
                  {
                    tw_pr($user_tb,$pdo,$prefecture);
                  }
                    else if($prefecture == "新潟")
                    {
                      tw_pr($user_tb,$pdo,$prefecture);
                    }
                      else if($prefecture == "富山")
                      {
                        tw_pr($user_tb,$pdo,$prefecture);
                      }
                        else if($prefecture == "石川")
                        {
                          tw_pr($user_tb,$pdo,$prefecture);
                        }
                          else if($prefecture == "福井")
                          {tw_pr($user_tb,$pdo,$prefecture);
                          }
                            else if($prefecture == "山梨")
                            {
                              tw_pr($user_tb,$pdo,$prefecture);
                            }
                              else if($prefecture == "長野")
                              {
                                tw_pr($user_tb,$pdo,$prefecture);
                              }
                                else if($prefecture == "岐阜")
                                {
                                  tw_pr($user_tb,$pdo,$prefecture);
                                }
                                  else if($prefecture == "静岡")
                                  {
                                    tw_pr($user_tb,$pdo,$prefecture);
                                  }
                                    else if($prefecture == "愛知")
                                    {
                                      tw_pr($user_tb,$pdo,$prefecture);
                                    }
                                      else if($prefecture == "三重")
                                      {
                                        tw_pr($user_tb,$pdo,$prefecture);
                                      }
                                        else if($prefecture == "滋賀")
                                        {
                                          tw_pr($user_tb,$pdo,$prefecture);
                                        }
                                          else if($prefecture == "大阪")
                                          {
                                            tw_pr($user_tb,$pdo,$prefecture);
                                          }
                                            else if($prefecture == "京都")
                                            {
                                              tw_pr($user_tb,$pdo,$prefecture);
                                            }
                                              else if($prefecture == "兵庫")
                                              {
                                                tw_pr($user_tb,$pdo,$prefecture);
                                              }
                                                else if($prefecture == "奈良")
                                                {
                                                  tw_pr($user_tb,$pdo,$prefecture);
                                                }
                                                  else if($prefecture == "和歌山")
                                                  {
                                                    tw_pr($user_tb,$pdo,$prefecture);
                                                  }
                                                    else if($prefecture == "鳥取")
                                                    {
                                                      tw_pr($user_tb,$pdo,$prefecture);
                                                    }
                                                      else if($prefecture == "島根")
                                                      {
                                                        tw_pr($user_tb,$pdo,$prefecture);
                                                      }
                                                        else if($prefecture == "岡山")
                                                        {
                                                          tw_pr($user_tb,$pdo,$prefecture);
                                                        }
                                                          else if($prefecture == "広島")
                                                          {
                                                            tw_pr($user_tb,$pdo,$prefecture);
                                                          }
                                                            else if($prefecture == "山口")
                                                            {
                                                              tw_pr($user_tb,$pdo,$prefecture);
                                                            }
                                                              else if($prefecture == "徳島")
                                                              {
                                                                tw_pr($user_tb,$pdo,$prefecture);
                                                              }
                                                                else if($prefecture == "香川")
                                                                {
                                                                  tw_pr($user_tb,$pdo,$prefecture);
                                                                }
                                                                  else if($prefecture == "愛媛")
                                                                  {
                                                                    tw_pr($user_tb,$pdo,$prefecture);
                                                                  }
                                                                    else if($prefecture == "高知")
                                                                    {
                                                                      tw_pr($user_tb,$pdo,$prefecture);
                                                                    }
                                                                      else if($prefecture == "福岡")
                                                                      {
                                                                        tw_pr($user_tb,$pdo,$prefecture);
                                                                      }
                                                                        else if($prefecture == "佐賀")
                                                                        {
                                                                          tw_pr($user_tb,$pdo,$prefecture);
                                                                        }
                                                                          else if($prefecture == "長崎")
                                                                          {
                                                                            tw_pr($user_tb,$pdo,$prefecture);
                                                                          }
                                                                            else if($prefecture == "熊本")
                                                                            {
                                                                              tw_pr($user_tb,$pdo,$prefecture);
                                                                            }
                                                                              else if($prefecture == "大分")
                                                                              {
                                                                                tw_pr($user_tb,$pdo,$prefecture);
                                                                              }
                                                                                else if($prefecture == "宮崎")
                                                                                {
                                                                                  tw_pr($user_tb,$pdo,$prefecture);
                                                                                }
                                                                                  else if($prefecture == "鹿児島")
                                                                                  {
                                                                                    tw_pr($user_tb,$pdo,$prefecture);
                                                                                  }
                                                                                    else if($prefecture == "沖縄")
                                                                                    {
                                                                                      tw_pr($user_tb,$pdo,$prefecture);
                                                                                    }
                                                                                      else
                                                                                      {echo "";}
 ?>
  </body>
  </html>
